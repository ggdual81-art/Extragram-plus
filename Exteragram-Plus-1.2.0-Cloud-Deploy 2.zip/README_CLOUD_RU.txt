EXTERAGRAM PLUS 1.2.0 — CLOUD DEPLOY PACKAGE
=============================================

Что входит
- plugin/exteragram_plus.plugin — плагин Exteragram Plus (Python SDK).
- server/app.py — FastAPI API на PostgreSQL.
- server/bot.py — Telegram-бот (polling запускается вместе с API).
- server/static/admin.html — веб-панель владельца.
- render.yaml — Render Blueprint.
- server/Dockerfile и requirements.txt.

ВАЖНО: сервер не опубликован автоматически. Для публикации нужен твой Render,
GitHub и Neon аккаунты и явное подключение этих аккаунтов. Не отправляй сюда
пароли, BOT_TOKEN, APP_SECRET или DATABASE_URL.

РЕКОМЕНДУЕМАЯ БЕСПЛАТНАЯ СХЕМА
- Render Free Web Service — API + бот в одном процессе.
- Neon Free PostgreSQL — постоянная база.
Render Free Web Service засыпает после 15 минут без трафика, а первый запрос
после сна может ждать около минуты. Файловая система Render Free временная,
поэтому приложение не хранит пользовательские данные локально.
Neon Free имеет квоты/лимиты и масштабируется до нуля при простое. Это тестовый
вариант, а не гарантия постоянной доступности или production SLA.

ПУБЛИКАЦИЯ
1. Создай пустой GitHub-репозиторий.
2. Загрузи в него ВСЁ содержимое архива, включая render.yaml в корне.
3. Создай проект PostgreSQL в Neon. В Neon Console нажми Connect и скопируй
   pooled connection string (hostname содержит -pooler); храни его как секрет.
4. Создай Telegram-бота через официального @BotFather, скопируй BOT_TOKEN.
5. Узнай свой числовой Telegram ID (OWNER_TELEGRAM_ID).
6. Открой Render Dashboard → New → Blueprint и выбери репозиторий.
7. Render прочитает render.yaml и создаст Web Service. Заполни:
   DATABASE_URL = строка подключения Neon
   BOT_TOKEN = токен бота
   OWNER_TELEGRAM_ID = твой числовой Telegram ID
   APP_SECRET = длинный случайный секрет (Render может сгенерировать его)
8. Нажми Apply и дождись успешного deploy.
9. Открой https://ИМЯ-СЕРВИСА.onrender.com/api/health.
   Должно вернуться JSON с ok=true и database=connected.
10. Открой https://ИМЯ-СЕРВИСА.onrender.com/admin для панели владельца.
11. В Exteragram Plus укажи этот HTTPS URL в поле API, сохрани, открой бота,
    отправь /start и /link, введи одноразовый код в плагине и нажми привязку.

ПРОВЕРКА
- GET /api/health — API и PostgreSQL.
- GET /docs — документация API.
- GET /admin — админ-панель.
- Telegram /link — код привязки, действует 10 минут.
- Telegram /admin — сводка только для OWNER_TELEGRAM_ID.

БЕЗОПАСНОСТЬ
- Не публикуй .env, BOT_TOKEN, APP_SECRET, DATABASE_URL или bearer-токены.
- Не вставляй секреты в исходный код или GitHub.
- Для панели владельца используй только свой токен; не пересылай его.
- Включи HTTPS (Render предоставляет TLS на onrender.com).
- Бесплатные сервисы могут засыпать, перезапускаться и иметь лимиты.
- Перед реальным запуском для других пользователей добавим rate limiting,
  отзыв/ротацию токенов, резервное копирование и защиту от спама.

ЧТО УЖЕ ЕСТЬ В КОДЕ
- PostgreSQL-схема пользователей, профилей, коллекций, подарков и аудита.
- Одноразовые коды Telegram-привязки с HMAC-хешированием.
- Выдача bearer-токенов.
- API каталога, инвентаря, экипировки, подарков и панели администратора.
- Начальный каталог: модели, фоны, узоры, подарки.
- Админка: статистика, добавление элементов, список пользователей.

ОГРАНИЧЕНИЯ ТЕКУЩЕГО РЕЛИЗА
- NFT/подарки — внутренняя система Exteragram Plus; не изменяет официальный
  Telegram-профиль и не отправляет настоящие Telegram Gifts.
- Графический Android-превью и нативное применение к Telegram-профилю ещё
  не реализованы. Плагин работает с внутренней коллекцией через API.
- Текущая реализация Telegram-бота и API объединены в один web service; для
  масштабирования бот лучше вынести в отдельный worker.
