import os, time, secrets, hashlib, hmac, threading
from contextlib import contextmanager
from typing import Optional
import psycopg
from psycopg.rows import dict_row
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

DATABASE_URL = os.getenv("DATABASE_URL", "")
APP_SECRET = os.getenv("APP_SECRET", "")
OWNER_ID = int(os.getenv("OWNER_TELEGRAM_ID", "0") or 0)
STATIC = os.path.join(os.path.dirname(__file__), "static")

app = FastAPI(title="Exteragram Plus API", version="1.2.0")
app.mount("/static", StaticFiles(directory=STATIC), name="static")

@contextmanager
def db():
    if not DATABASE_URL:
        raise RuntimeError("DATABASE_URL is not configured")
    conn = psycopg.connect(DATABASE_URL, row_factory=dict_row, connect_timeout=10)
    try:
        with conn:
            yield conn
    finally:
        conn.close()

def digest(value: str) -> str:
    if not APP_SECRET:
        raise RuntimeError("APP_SECRET is not configured")
    return hmac.new(APP_SECRET.encode(), value.encode(), hashlib.sha256).hexdigest()

def init_db():
    statements = [
        """CREATE TABLE IF NOT EXISTS users(
            tg_id BIGINT PRIMARY KEY, username TEXT NOT NULL DEFAULT '',
            display_name TEXT NOT NULL DEFAULT '', created_at BIGINT NOT NULL)""",
        """CREATE TABLE IF NOT EXISTS tokens(
            token_hash TEXT PRIMARY KEY, tg_id BIGINT NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
            created_at BIGINT NOT NULL)""",
        """CREATE TABLE IF NOT EXISTS pairing_codes(
            code_hash TEXT PRIMARY KEY, tg_id BIGINT NOT NULL,
            expires_at BIGINT NOT NULL, used BOOLEAN NOT NULL DEFAULT FALSE)""",
        """CREATE TABLE IF NOT EXISTS profiles(
            tg_id BIGINT PRIMARY KEY REFERENCES users(tg_id) ON DELETE CASCADE,
            bio TEXT NOT NULL DEFAULT '', theme TEXT NOT NULL DEFAULT 'midnight',
            rating INTEGER NOT NULL DEFAULT 0)""",
        """CREATE TABLE IF NOT EXISTS catalog(
            id BIGSERIAL PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('model','background','pattern','gift')),
            title TEXT NOT NULL, description TEXT NOT NULL DEFAULT '',
            asset_key TEXT NOT NULL DEFAULT '', rarity TEXT NOT NULL DEFAULT 'common',
            enabled BOOLEAN NOT NULL DEFAULT TRUE)""",
        """CREATE TABLE IF NOT EXISTS inventory(
            id BIGSERIAL PRIMARY KEY, tg_id BIGINT NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
            catalog_id BIGINT NOT NULL REFERENCES catalog(id), acquired_at BIGINT NOT NULL)""",
        """CREATE TABLE IF NOT EXISTS profile_items(
            tg_id BIGINT NOT NULL REFERENCES users(tg_id) ON DELETE CASCADE,
            slot TEXT NOT NULL CHECK(slot IN ('avatar','background','pattern')),
            catalog_id BIGINT NOT NULL REFERENCES catalog(id), PRIMARY KEY(tg_id,slot))""",
        """CREATE TABLE IF NOT EXISTS gifts(
            id BIGSERIAL PRIMARY KEY, sender_id BIGINT NOT NULL REFERENCES users(tg_id),
            receiver_id BIGINT NOT NULL REFERENCES users(tg_id), catalog_id BIGINT NOT NULL REFERENCES catalog(id),
            message TEXT NOT NULL DEFAULT '', created_at BIGINT NOT NULL)""",
        """CREATE TABLE IF NOT EXISTS audit(
            id BIGSERIAL PRIMARY KEY, actor_id BIGINT, action TEXT NOT NULL,
            target TEXT NOT NULL DEFAULT '', created_at BIGINT NOT NULL)"""
    ]
    with db() as con:
        for sql in statements:
            con.execute(sql)
        count = con.execute("SELECT COUNT(*) AS n FROM catalog").fetchone()["n"]
        if count == 0:
            seed = [
                ("model","Aurora","Кристаллическая аватара","model_aurora","rare"),
                ("model","Nova","Геометрическая аватара","model_nova","common"),
                ("model","Orbit","Космическая аватара","model_orbit","epic"),
                ("background","Midnight","Глубокий ночной фон","bg_midnight","common"),
                ("background","Nebula","Туманность с мягким свечением","bg_nebula","rare"),
                ("background","Prism","Переливающийся градиент","bg_prism","epic"),
                ("pattern","Circuit","Тонкий технологичный узор","pattern_circuit","common"),
                ("pattern","Waves","Абстрактные волны","pattern_waves","rare"),
                ("pattern","Glyph","Геометрические знаки","pattern_glyph","epic"),
                ("gift","Star","Звёздный подарок","gift_star","common"),
                ("gift","Crystal","Кристалл","gift_crystal","rare"),
                ("gift","Comet","Комета","gift_comet","epic"),
            ]
            con.executemany(
                "INSERT INTO catalog(kind,title,description,asset_key,rarity) VALUES(%s,%s,%s,%s,%s)",
                seed
            )

def current_user(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    try:
        token_hash = digest(authorization[7:].strip())
        with db() as con:
            row = con.execute("SELECT tg_id FROM tokens WHERE token_hash=%s", (token_hash,)).fetchone()
    except RuntimeError as exc:
        raise HTTPException(503, str(exc))
    if row is None:
        raise HTTPException(401, "Invalid token")
    return int(row["tg_id"])

def owner_user(user_id: int = Depends(current_user)):
    if not OWNER_ID or user_id != OWNER_ID:
        raise HTTPException(403, "Owner only")
    return user_id

class PairCode(BaseModel):
    code: str = Field(min_length=6, max_length=12)

class ProfileUpdate(BaseModel):
    display_name: Optional[str] = Field(default=None, max_length=64)
    bio: Optional[str] = Field(default=None, max_length=300)
    theme: Optional[str] = Field(default=None, max_length=32)

class GiftSend(BaseModel):
    receiver_id: int
    catalog_id: int
    message: str = Field(default="", max_length=180)

class EquipItem(BaseModel):
    catalog_id: int
    slot: str = Field(pattern="^(avatar|background|pattern)$")

class CatalogItem(BaseModel):
    kind: str = Field(pattern="^(model|background|pattern|gift)$")
    title: str = Field(min_length=1, max_length=80)
    description: str = Field(default="", max_length=300)
    asset_key: str = Field(default="", max_length=100)
    rarity: str = Field(default="common", pattern="^(common|rare|epic|legendary)$")

@app.on_event("startup")
def startup():
    init_db()
    # One Render web service can host the polling bot alongside FastAPI.
    if os.getenv("BOT_TOKEN"):
        def bot_runner():
            try:
                from bot import run_bot
                run_bot()
            except Exception as exc:
                print("Telegram bot stopped:", repr(exc), flush=True)
        threading.Thread(target=bot_runner, daemon=True, name="telegram-bot").start()

@app.get("/")
def root():
    return {"service":"Exteragram Plus API", "version":"1.2.0", "docs":"/docs", "admin":"/admin"}

@app.get("/admin")
def admin():
    return FileResponse(os.path.join(STATIC, "admin.html"))

@app.get("/api/health")
def health():
    try:
        with db() as con:
            con.execute("SELECT 1")
        return {"ok":True, "service":"exteragram-plus", "version":"1.2.0", "database":"connected"}
    except Exception as exc:
        raise HTTPException(503, "Database unavailable: " + str(exc)[:180])

@app.post("/api/auth/exchange")
def exchange(payload: PairCode):
    try:
        code_hash = digest(payload.code.upper())
    except RuntimeError as exc:
        raise HTTPException(503, str(exc))
    with db() as con:
        row = con.execute("SELECT tg_id,expires_at,used FROM pairing_codes WHERE code_hash=%s FOR UPDATE",
                          (code_hash,)).fetchone()
        if not row or row["used"] or row["expires_at"] < int(time.time()):
            raise HTTPException(400, "Pairing code is invalid or expired")
        tg_id = int(row["tg_id"])
        con.execute("UPDATE pairing_codes SET used=TRUE WHERE code_hash=%s", (code_hash,))
        con.execute("INSERT INTO users(tg_id,created_at) VALUES(%s,%s) ON CONFLICT(tg_id) DO NOTHING",
                    (tg_id,int(time.time())))
        con.execute("INSERT INTO profiles(tg_id) VALUES(%s) ON CONFLICT(tg_id) DO NOTHING", (tg_id,))
        token = secrets.token_urlsafe(36)
        con.execute("INSERT INTO tokens(token_hash,tg_id,created_at) VALUES(%s,%s,%s)",
                    (digest(token),tg_id,int(time.time())))
    return {"access_token":token,"token_type":"bearer","user_id":tg_id}

@app.get("/api/me")
def me(user_id: int = Depends(current_user)):
    with db() as con:
        user = con.execute("SELECT tg_id,username,display_name,created_at FROM users WHERE tg_id=%s",(user_id,)).fetchone()
        profile = con.execute("SELECT bio,theme,rating FROM profiles WHERE tg_id=%s",(user_id,)).fetchone()
        inv = con.execute("""SELECT c.id,c.kind,c.title,c.asset_key,c.rarity,i.acquired_at
                             FROM inventory i JOIN catalog c ON c.id=i.catalog_id
                             WHERE i.tg_id=%s ORDER BY i.acquired_at DESC""",(user_id,)).fetchall()
        equipped = con.execute("""SELECT p.slot,p.catalog_id,c.title,c.asset_key,c.rarity
                                  FROM profile_items p JOIN catalog c ON c.id=p.catalog_id
                                  WHERE p.tg_id=%s""",(user_id,)).fetchall()
    return {"user":dict(user) if user else {"tg_id":user_id}, "profile":dict(profile) if profile else {},
            "inventory":[dict(x) for x in inv], "equipped":[dict(x) for x in equipped]}

@app.patch("/api/me/profile")
def update_profile(payload: ProfileUpdate, user_id: int = Depends(current_user)):
    values = payload.model_dump(exclude_none=True)
    with db() as con:
        if "display_name" in values:
            con.execute("UPDATE users SET display_name=%s WHERE tg_id=%s",(values.pop("display_name"),user_id))
        if values:
            con.execute("INSERT INTO profiles(tg_id) VALUES(%s) ON CONFLICT(tg_id) DO NOTHING",(user_id,))
            for key,value in values.items():
                if key in ("bio","theme"):
                    con.execute(f"UPDATE profiles SET {key}=%s WHERE tg_id=%s",(value,user_id))
    return {"ok":True,"updated":list(payload.model_dump(exclude_none=True))}

@app.get("/api/catalog")
def catalog(kind: Optional[str] = None, user_id: int = Depends(current_user)):
    with db() as con:
        if kind:
            rows = con.execute("SELECT id,kind,title,description,asset_key,rarity FROM catalog WHERE enabled=TRUE AND kind=%s ORDER BY id",(kind,)).fetchall()
        else:
            rows = con.execute("SELECT id,kind,title,description,asset_key,rarity FROM catalog WHERE enabled=TRUE ORDER BY kind,id").fetchall()
    return {"items":[dict(x) for x in rows]}

@app.post("/api/inventory/{catalog_id}")
def acquire(catalog_id: int, user_id: int = Depends(current_user)):
    with db() as con:
        item = con.execute("SELECT id,kind FROM catalog WHERE id=%s AND enabled=TRUE",(catalog_id,)).fetchone()
        if not item or item["kind"] == "gift":
            raise HTTPException(404,"Collectible not found")
        con.execute("INSERT INTO inventory(tg_id,catalog_id,acquired_at) VALUES(%s,%s,%s)",
                    (user_id,catalog_id,int(time.time())))
    return {"ok":True,"catalog_id":catalog_id}

@app.put("/api/me/equip")
def equip(payload: EquipItem, user_id: int = Depends(current_user)):
    expected = {"avatar":"model","background":"background","pattern":"pattern"}[payload.slot]
    with db() as con:
        owned = con.execute("""SELECT 1 FROM inventory i JOIN catalog c ON c.id=i.catalog_id
                               WHERE i.tg_id=%s AND i.catalog_id=%s AND c.kind=%s""",
                            (user_id,payload.catalog_id,expected)).fetchone()
        if not owned:
            raise HTTPException(403,"Item is not in your inventory")
        con.execute("""INSERT INTO profile_items(tg_id,slot,catalog_id) VALUES(%s,%s,%s)
                       ON CONFLICT(tg_id,slot) DO UPDATE SET catalog_id=EXCLUDED.catalog_id""",
                    (user_id,payload.slot,payload.catalog_id))
    return {"ok":True,"slot":payload.slot,"catalog_id":payload.catalog_id}

@app.post("/api/gifts/send")
def send_gift(payload: GiftSend, user_id: int = Depends(current_user)):
    if payload.receiver_id == user_id:
        raise HTTPException(400,"Cannot send a gift to yourself")
    with db() as con:
        item = con.execute("SELECT id,kind FROM catalog WHERE id=%s AND enabled=TRUE",(payload.catalog_id,)).fetchone()
        receiver = con.execute("SELECT tg_id FROM users WHERE tg_id=%s",(payload.receiver_id,)).fetchone()
        if not item or item["kind"] != "gift": raise HTTPException(404,"Gift not found")
        if not receiver: raise HTTPException(404,"Recipient is not registered in Exteragram Plus")
        con.execute("INSERT INTO gifts(sender_id,receiver_id,catalog_id,message,created_at) VALUES(%s,%s,%s,%s,%s)",
                    (user_id,payload.receiver_id,payload.catalog_id,payload.message,int(time.time())))
    return {"ok":True}

@app.get("/api/me/gifts")
def my_gifts(user_id: int = Depends(current_user)):
    with db() as con:
        rows = con.execute("""SELECT g.id,g.sender_id,g.receiver_id,g.message,g.created_at,
                              c.title,c.asset_key,c.rarity FROM gifts g JOIN catalog c ON c.id=g.catalog_id
                              WHERE g.receiver_id=%s ORDER BY g.created_at DESC""",(user_id,)).fetchall()
    return {"gifts":[dict(x) for x in rows]}

@app.get("/api/admin/overview")
def overview(user_id: int = Depends(owner_user)):
    with db() as con:
        users = con.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
        items = con.execute("SELECT COUNT(*) AS n FROM catalog").fetchone()["n"]
        gifts = con.execute("SELECT COUNT(*) AS n FROM gifts").fetchone()["n"]
    return {"users":users,"catalog_items":items,"gifts_sent":gifts}

@app.post("/api/admin/catalog")
def add_catalog(payload: CatalogItem, user_id: int = Depends(owner_user)):
    with db() as con:
        row = con.execute("""INSERT INTO catalog(kind,title,description,asset_key,rarity)
                             VALUES(%s,%s,%s,%s,%s) RETURNING id""",
                          (payload.kind,payload.title,payload.description,payload.asset_key,payload.rarity)).fetchone()
        con.execute("INSERT INTO audit(actor_id,action,target,created_at) VALUES(%s,%s,%s,%s)",
                    (user_id,"catalog.create",str(row["id"]),int(time.time())))
    return {"id":row["id"],"ok":True}

@app.get("/api/admin/users")
def admin_users(user_id: int = Depends(owner_user)):
    with db() as con:
        rows = con.execute("SELECT tg_id,username,display_name,created_at FROM users ORDER BY created_at DESC LIMIT 200").fetchall()
    return {"users":[dict(x) for x in rows]}
