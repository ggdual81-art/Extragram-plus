import os, time, secrets, hmac, hashlib
import psycopg
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

TOKEN = os.getenv("BOT_TOKEN","")
OWNER_ID = int(os.getenv("OWNER_TELEGRAM_ID","0") or 0)
DATABASE_URL = os.getenv("DATABASE_URL","")
APP_SECRET = os.getenv("APP_SECRET","")

def code_digest(code):
    if not APP_SECRET:
        raise RuntimeError("APP_SECRET is missing")
    return hmac.new(APP_SECRET.encode(), code.encode(), hashlib.sha256).hexdigest()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Exteragram Plus\\n/link — одноразовый код привязки\\n/help — справка"
    )

async def link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    code = secrets.token_urlsafe(6).replace("-","").replace("_","").upper()[:8]
    with psycopg.connect(DATABASE_URL) as con:
        con.execute("INSERT INTO pairing_codes(code_hash,tg_id,expires_at,used) VALUES(%s,%s,%s,FALSE)",
                    (code_digest(code),uid,int(time.time())+600))
        con.execute("INSERT INTO users(tg_id,username,display_name,created_at) VALUES(%s,%s,%s,%s) "
                    "ON CONFLICT(tg_id) DO UPDATE SET username=EXCLUDED.username, display_name=EXCLUDED.display_name",
                    (uid,update.effective_user.username or "",update.effective_user.full_name or "",int(time.time())))
        con.execute("INSERT INTO profiles(tg_id) VALUES(%s) ON CONFLICT(tg_id) DO NOTHING",(uid,))
    await update.message.reply_text(
        f"Код привязки: {code}\\nДействует 10 минут. Введи его в настройках Exteragram Plus. Не пересылай код."
    )

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привязка: /link. Код одноразовый, срок действия — 10 минут.")

async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not OWNER_ID or update.effective_user.id != OWNER_ID:
        await update.message.reply_text("Команда доступна только владельцу.")
        return
    with psycopg.connect(DATABASE_URL) as con:
        u = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        c = con.execute("SELECT COUNT(*) FROM catalog").fetchone()[0]
        g = con.execute("SELECT COUNT(*) FROM gifts").fetchone()[0]
    await update.message.reply_text(f"Exteragram Plus admin\\nПользователи: {u}\\nКаталог: {c}\\nПодарки: {g}")

def run_bot():
    if not TOKEN or not DATABASE_URL or not APP_SECRET:
        raise RuntimeError("BOT_TOKEN, DATABASE_URL and APP_SECRET are required")
    application = Application.builder().token(TOKEN).build()
    application.add_handler(CommandHandler("start",start))
    application.add_handler(CommandHandler("link",link))
    application.add_handler(CommandHandler("help",help_cmd))
    application.add_handler(CommandHandler("admin",admin))
    application.run_polling()

if __name__ == "__main__":
    run_bot()
