from base_plugin import BasePlugin
from ui.settings import Header, Divider, Input, Text, Selector
from typing import Any, List
import json
import threading
import urllib.request
import urllib.error

__id__ = "exteragram_plus"
__name__ = "Exteragram Plus"
__description__ = "Независимая платформа коллекций, подарков и оформления профиля."
__author__ = "Exteragram Plus"
__version__ = "1.2.0"
__icon__ = "exteraPlugins/1"
__app_version__ = ">=12.5.1"
__sdk_version__ = ">=1.4.4.3"
__category__ = ["appearance", "fun", "integrations"]

DEFAULT_API = ""


class ExteragramPlusPlugin(BasePlugin):
    """Independent client for the Exteragram Plus API."""

    def on_plugin_load(self):
        if self.get_setting("api_url", None) is None:
            self.set_setting("api_url", DEFAULT_API)
        if self.get_setting("catalog_cache", None) is None:
            self.set_setting("catalog_cache", "[]")
        self.logger.info("Exteragram Plus 1.1.0 loaded")

    def _api(self, method, path, payload=None, token=None):
        root = (self.get_setting("api_url", "") or "").strip().rstrip("/")
        if not root.startswith("https://") and not root.startswith("http://"):
            raise RuntimeError("Сначала укажи адрес опубликованного API-сервера")
        data = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = {"Accept": "application/json"}
        if data is not None:
            headers["Content-Type"] = "application/json"
        if token:
            headers["Authorization"] = "Bearer " + token
        req = urllib.request.Request(root + path, data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=15) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}

    def _run_async(self, label, action, reload_after=False):
        def worker():
            try:
                result = action()
                self.logger.info("%s: %s", label, result)
                if reload_after:
                    self.set_setting("last_action", label, reload_settings=True)
            except urllib.error.HTTPError as exc:
                try:
                    detail = exc.read().decode("utf-8")[:400]
                except Exception:
                    detail = str(exc)
                self.logger.error("%s HTTP %s: %s", label, exc.code, detail)
            except Exception as exc:
                self.logger.exception("%s failed: %s", label, exc)
        threading.Thread(target=worker, daemon=True).start()

    def _token(self):
        token = self.get_setting("access_token", "") or ""
        if not token:
            raise RuntimeError("Сначала привяжи аккаунт через Telegram-бота")
        return token

    def _check_server(self, view=None):
        self._run_async("API health", lambda: self._api("GET", "/api/health"))

    def _connect(self, view=None):
        code = (self.get_setting("pair_code", "") or "").strip().upper()
        if not code:
            self.logger.warning("Введи одноразовый код из Telegram-бота /link")
            return

        def action():
            result = self._api("POST", "/api/auth/exchange", {"code": code})
            token = result.get("access_token")
            if not token:
                raise RuntimeError("Сервер не вернул access token")
            self.set_setting("access_token", token)
            self.set_setting("linked_user_id", str(result.get("user_id", "")))
            self.set_setting("pair_code", "")
            return {"user_id": result.get("user_id"), "connected": True}
        self._run_async("Account link", action, True)

    def _disconnect(self, view=None):
        self.set_setting("access_token", "")
        self.set_setting("linked_user_id", "")
        self.logger.info("Токен удалён с устройства")

    def _refresh_catalog(self, view=None):
        try:
            token = self._token()
        except Exception as exc:
            self.logger.warning(str(exc))
            return

        def action():
            result = self._api("GET", "/api/catalog", token=token)
            items = result.get("items", [])
            self.set_setting("catalog_cache", json.dumps(items, ensure_ascii=False))
            self.set_setting("catalog_updated", str(len(items)))
            return {"items": len(items), "message": "Каталог сохранён локально"}
        self._run_async("Catalog refresh", action, True)

    def _catalog(self):
        try:
            items = json.loads(self.get_setting("catalog_cache", "[]") or "[]")
            return items if isinstance(items, list) else []
        except Exception:
            return []

    def _create_catalog_page(self, kind):
        items = [x for x in self._catalog() if x.get("kind") == kind]
        labels = [f'{x.get("title","Без названия")} · {x.get("rarity","common")}' for x in items]
        title = {"model": "Модели NFT", "background": "Фоны", "pattern": "Узоры"}[kind]
        slot = {"model": "avatar", "background": "background", "pattern": "pattern"}[kind]
        key = "selected_" + kind
        current = int(self.get_setting(key, 0) or 0)
        if current < 0 or current >= len(labels):
            current = 0
        page = [
            Header(text=title),
            Text(text=f"В каталоге: {len(items)} элементов",
                 subtext="Сначала обнови каталог на главной странице плагина, если список пуст."),
        ]
        if labels:
            page.append(Selector(
                key=key, text="Выбери элемент", default=current,
                items=labels, icon="msg_gallery",
                on_change=lambda index, k=key: self.set_setting(k, int(index)),
            ))
            page.append(Text(
                text="Добавить в коллекцию и применить",
                subtext="Предмет будет записан в коллекцию Exteragram Plus и выбран в профиле внутри нашей системы.",
                icon="msg_check",
                accent=True,
                on_click=lambda view, k=kind, s=slot: self._acquire_and_equip(k, s),
            ))
            selected = items[current]
            page.append(Text(text="Предпросмотр выбранного элемента",
                             subtext=f'{selected.get("title","")} · {selected.get("description","")}'))
        else:
            page.append(Text(text="Каталог пока пуст", subtext="Вернись назад и нажми «Обновить каталог»."))
        return page

    def _acquire_and_equip(self, kind, slot):
        items = [x for x in self._catalog() if x.get("kind") == kind]
        index = int(self.get_setting("selected_" + kind, 0) or 0)
        if not items or index < 0 or index >= len(items):
            self.logger.warning("Сначала обнови каталог и выбери элемент")
            return
        item = items[index]
        try:
            token = self._token()
        except Exception as exc:
            self.logger.warning(str(exc))
            return

        def action():
            self._api("POST", f'/api/inventory/{int(item["id"])}', token=token)
            result = self._api("PUT", "/api/me/equip",
                               {"catalog_id": int(item["id"]), "slot": slot}, token=token)
            return {"item": item.get("title"), "slot": slot, "result": result}
        self._run_async("NFT equipped", action)

    def _create_studio_page(self):
        return [
            Header(text="EXTERAGRAM PLUS · NFT STUDIO"),
            Text(text="Обновить полный каталог",
                 subtext="Загружает модели, фоны, узоры и сохраняет список на устройстве.",
                 icon="msg_refresh", accent=True, on_click=self._refresh_catalog),
            Divider(text="Конструктор"),
            Text(text="Модели", icon="msg_user", create_sub_fragment=lambda: self._create_catalog_page("model")),
            Text(text="Фоны", icon="msg_image", create_sub_fragment=lambda: self._create_catalog_page("background")),
            Text(text="Узоры", icon="msg_brush", create_sub_fragment=lambda: self._create_catalog_page("pattern")),
            Divider(text="Текущий каталог"),
            Text(text=f'Сохранено элементов: {len(self._catalog())}',
                 subtext="После обновления открой конструктор заново."),
        ]

    def _create_profile_page(self):
        return [
            Header(text="Мой профиль Exteragram Plus"),
            Text(text="Открыть профиль через API",
                 subtext="Загружает профиль и коллекцию в журнал плагина.",
                 on_click=self._load_profile, icon="msg_user"),
            Text(text="Подарки",
                 subtext="Полученные виртуальные подарки доступны через API.",
                 on_click=self._load_gifts, icon="msg_gift"),
        ]

    def _load_profile(self, view=None):
        try:
            token = self._token()
        except Exception as exc:
            self.logger.warning(str(exc)); return
        self._run_async("Profile", lambda: self._api("GET", "/api/me", token=token))

    def _load_gifts(self, view=None):
        try:
            token = self._token()
        except Exception as exc:
            self.logger.warning(str(exc)); return
        self._run_async("Gifts", lambda: self._api("GET", "/api/me/gifts", token=token))

    def create_settings(self) -> List[Any]:
        linked = bool(self.get_setting("access_token", ""))
        user_id = self.get_setting("linked_user_id", "—") or "—"
        count = len(self._catalog())
        return [
            Header(text="EXTERAGRAM PLUS"),
            Text(text="MODERN EDITION · 1.2.0",
                 subtext="Собственный каталог, коллекции и API"),
            Divider(text="Сервер и аккаунт"),
            Input(key="api_url", text="HTTPS-адрес API",
                  default=self.get_setting("api_url", ""),
                  subtext="Вставь публичный URL своего облачного сервера."),
            Input(key="pair_code", text="Одноразовый код",
                  default="", subtext="Получи в Telegram-боте командой /link."),
            Text(text="Проверить сервер", icon="msg_network", on_click=self._check_server),
            Text(text="Привязать Telegram", icon="msg_key", accent=True, on_click=self._connect),
            Text(text=("Подключено · ID " + str(user_id)) if linked else "Аккаунт не подключён"),
            Text(text="Отключить аккаунт", icon="msg_logout", red=True, on_click=self._disconnect),
            Divider(text="Разделы"),
            Text(text="NFT-конструктор", icon="msg_gallery",
                 subtext=f"Модели, фоны и узоры · загружено: {count}",
                 create_sub_fragment=self._create_studio_page),
            Text(text="Мой профиль и подарки", icon="msg_user",
                 create_sub_fragment=self._create_profile_page),
            Divider(text="Информация"),
            Text(text="NFT и подарки являются внутренними предметами Exteragram Plus. Они не меняют официальный профиль Telegram и не являются настоящими Telegram-подарками."),
        ]

    def on_plugin_unload(self):
        self.logger.info("Exteragram Plus unloaded")
